import express from 'express';
import { Computers } from './database.mjs';
import { MainRouter } from './routes/index.mjs';

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static("src/public"));

app.use((req, res, next) => {
  console.log(`Request: ${req.method} ${req.originalUrl} ${req.socket.remoteAddress}`);
  next();
});

app.use("/", MainRouter);

app.get('/', (req, res) => {
  res.send('Hello World');
});

app.listen(process.env.PORT, () => {
  console.log('Server started on port ' + process.env.PORT);
});