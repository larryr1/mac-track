# API Schema

/api: N/A
  /computer: List all computers
    /:computer_id: Show specified compuuter
      /wake
      /delete
      /register